Start screen          
Introduction screen 
Character introduction 
Preface 
Chapter 1 (dilemma)
Transition screen 1(right) (the meaning of gem)/ transition screen 2 (wrong)
Chapter 2 (dilemma)
Transition screen 3(right) / transition screen 4 (wrong)
minigame(1)
Chapter 3 (dilemma)
Transition screen 5(right)/ transition screen 6 (wrong)
Chapter 4 (dilemma)
Transition screen 7(right)/ transition screen 8 (wrong)
minigame(2)
Chapter 5 (dilemma)
Transition screen 9(right)/ transition screen 10 (wrong)
Minigame (3)
Hidden message screen (The meaning of the gem(optional))
Ending message (editor’s message)
Return screen 